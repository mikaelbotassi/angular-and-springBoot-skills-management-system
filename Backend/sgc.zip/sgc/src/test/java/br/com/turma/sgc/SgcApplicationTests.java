package br.com.turma.sgc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgcApplicationTests {

	@Test
	void contextLoads() {
	}

}
